/*
* Description: Variation de la couleur d'une DEL selon l'intensité lumineuse ambiante.
* Auteur: Hubert Boucher, Alexandre Turcotte.
* Équipe: 211 de la section 05
* Date: 24/02/21
*
* Description des connextions: 
*   La DEL est connecter avec B0 et B1 de sorte qu'elle s'allume en vert si B0 est activé.
*   L'information analogique est connecter au port A0.
*   Une source de 5V est connecté à AVcc pour l'alimentation.
*   Un voltage de 5V est connecté à Aref.
*/

/* Calcul pour les conditions et description du comportement:

À 6K ohm la tension est de 1.88V donc 1.88*204.8 ~= 385 = 0x181 >> 2 = 0x60 = 96
À 8k ohm la tension est de 2.22V donc 2.22*204.8 ~= 454 = 0x1C6 >> 2 = 0x71 = 113

Lorsque la résistance est plus petite que 6K ohm, la DEL allume en rouge et, au contraire, elle s'allume en vert lorsque la
résistance est plus grande que 8k ohm. Ainsi, lorsque la résistance est plus petite ou égale à 8K ohm et plus grande ou egale 
à 6K ohm, la DEL s'allume ambré (Yellow dans notre code).
*/


#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);
#include "can.cpp"


//Definition de l'enum Color qui indique la couleur que la DEL doit prendre (Yellow est pour la couleur ambrée)
enum Color { SHUT, GREEN, YELLOW, RED };
Color color = SHUT;

int main()
{
    //Phase d'initialisation
    DDRA = 0x00; // PORT A est en mode entrée
    DDRB = 0xFF; // PORT B est en mode sortie
    can oCan = can();
    
    for (;;)
    {
        uint8_t lecture = (oCan.lecture(0) >> 2);

        //À 6K ohm la valeur de retour est 0x60 = 0110 0000
        if (lecture < ((0x01<<6) | (0x01<<5))) 
            color = RED;
        //À 8K ohm la valeur de retour est 0x71 = 0111 0001, l'intensité lumineuse est forte
        else if (lecture > ((0x01<<6) | (0x01<<5) | (0x01<<4) | (0x01)))
            color = GREEN;
        //La résistance est entre 6 et 8 K ohm, donc la l'intensité lumineuse est à un bon niveau
        else 
            color = YELLOW;

        //Nous déterminons à quel broche envoyer le coruant pour que la DEL soit rouge, jaune ou verte.
        switch (color)
        {
            case SHUT: PORTB = 0; break;

            case GREEN: PORTB = 0x01; break; //Ici, Le port B vaut 0x01, donc le courant sort par B0

            case RED: PORTB = (0x01 << 1); break; //Ici, Le port B vaut 0x02, donc le courant sort par B1

            case YELLOW: PORTB = (PORTB % 2 + 1); //on peut aussi écrire PORTB = ((PORTB & 0x01) + 1) //Ainsi, nous pouvons toggle la valeur de PortB
        }
    }

    return 0; 
}