/*
 * Nom:         TP 2, Problème 1
 * Auteurs:     Hubert Boucher & Alexandre Turcotte
 * Description: Machine de Moore (un clic sur A allume une LED verte, trois clics sur B la rendent rouge
 *              pendant une seconde, puis réinitialisation)
 * Version:     1.1
 */



#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);



/*

    TABLE DES ÉTATS
        E :  état courant
        A :  premier bouton (entrée D2 ici)
        B :  deuxième bouton (entrée D3 ici)
        X :  première sortie (sortie A0 ici)
        Y :  deuxième sortie (sortie A1 ici)
        C :  couleur de la LED (V pour vert, R pour rouge, E pour éteint)
        E+ : prochain état

    E       A   B       X   Y   C       E+

    init    0   x       0   0   E       init
    init    1   x       0   0   E       E1

    E1      x   0       1   0   V       E1
    E1      x   1       1   0   V       E2

    E2      x   0       1   0   V       E2
    E2      x   1       1   0   V       E3

    E3      x   0       1   0   V       E3
    E3      x   1       1   0   V       final

    final   x   x       0   1           init (après un délai de 1s)

*/



// The current state of the Moore machine
//  There is one initial state (shut), three intermediary states (green) and one final state (red)
enum State { init, S1, S2, S3, final };
State state = init;

// The color is determined by the machine's state
//  It can either be shut, green or red
enum Color { shut, green, red };
Color color = shut;

// The push state is used for each button to avoid repeating an action when maintaining the button over multiple cycles
// The "pulse" is a state occuring the moment the button is pressed and lasting only 1 cycle
// Once the button is released, the pulse can happen again
enum PushState
{
    unpushed, // Not pressed
    pulse, // For only one clock cycle when pressed
    pending // Pressed, after the first clock cycle
};
PushState A_state = unpushed;
PushState B_state = unpushed;



// Time constants
//  These are used to adjust delays
const double DELAY_ANTI_REBOUND = 10; //ms
const double DELAY_BEFORE_REINIT = 1000; //1000ms = 1s
const uint8_t PIN_A = 0b00000100; // D2
const uint8_t PIN_B = 0b00001000; // D3





// This function is used to get the next push state of a button according to its current state
//  The ID must be 0 for A, 1 for B
PushState NextPushState(PushState currentState, uint8_t pin)
{
    switch (currentState)
    {
        case unpushed:
            //Anti-rebound
            if (PIND & pin)
            {
                _delay_ms(DELAY_ANTI_REBOUND);
                if (PIND & pin)
                {
                    return pulse;
                }
            }
            break;

        case pulse:
            //Pulse should only last 1 cycle
            return pending;
            
        case pending:
            //Not anti-rebound on unclick
            if (!(PIND & pin))
            {
                return unpushed;
            }
            break;

        default:
            //This is not supposed to happen
            break;
    }

    // Keep the same state if no condition is met
    return currentState;
}



int main()
{
    // The ports A and D will be used
    DDRD = 0x00; // PORT D is an input
    DDRA = 0xff; // PORT A is an output

    for (;;)
    {
        // Set the color according to the current state
        //  Since it's a Moore machine, the output is only determined by the current state
        switch (state)
        {
            case init:
                color = shut;
                break;
            case S1:
                color = green;
                break;
            case S2:
                color = green;
                break;
            case S3:
                color = green;
                break;
            case final:
                color = red;
                break;

            default:
                //This is not supposed to happen : end the loop
                return 0;
        }
        
        // Set the LED according to the color
        switch (color)
        {
            case shut:
                PORTA = 0b00; // No tension, no color
                break;
            case green:
                PORTA = 0b01; // From A0 to A1 : green
                break;
            case red:
                PORTA = 0b10; // from A1 to A0 : red
                break;

            default:
                //This is not supposed to happen : end the loop
                return 0;
        }

        // Set the buttons' push state
        A_state = NextPushState(A_state, PIN_A);
        B_state = NextPushState(B_state, PIN_B);

        // Set next state according to the current state and to the A/B push state
        switch (state)
        {
            case init: //If button A has a pulse, change state (shut -> green)
                if (A_state == pulse)
                    state = S1;
                break;

            case S1: //If button B has a pulse, that's 1
                if (B_state == pulse)
                    state = S2;
                break;

            case S2: //If button B has a pulse, that's 2
                if (B_state == pulse)
                    state = S3;
                break;

            case S3: //If button B has a pulse, that's 3 : change state (green -> red)
                if (B_state == pulse)
                    state = final;
                break;

            case final:
                _delay_ms(DELAY_BEFORE_REINIT); //Wait a bit, the reinitialize (red -> shut)
                state = init;
                break;

            default:
                //This is not supposed to happen : end the loop
                return 0;
        }
    }

    return 0;
}