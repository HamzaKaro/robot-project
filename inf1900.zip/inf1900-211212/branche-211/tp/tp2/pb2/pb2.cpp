/*
 * Machine à états de Moore contrôlant l'allumage d'une LED, premier problème.
 * Date : 27/01/2021
 * Auteur : Alexandre Turcotte, Hubert Boucher
 * Équipe : 211
 * Groupe 05
*/

/*
 * État présent     Entrée D2   Entrée D3    État suivant     Sortie A
 * INIT                0            0           INIT            0
 * INIT                0            1           INIT            0
 * INIT                1            0           ROUGE           0
 * ROUGE               0            0           ROUGE           1
 * ROUGE               0            1           ETEINT          1
 * ROUGE               1            0           VERT            1
 * VERT                0            0           VERT            2
 * VERT                0            1           INIT            2
 * VERT                1            0           INIT            2
 * ETEINT              0            0           ETEINT          0
 * ETEINT              0            1           VERT            0
 * ETEINT              1            0           ???             0
*/


#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);

bool debounce(uint8_t registreD){
    if(registreD & 0xC){
        _delay_ms(10);
        return !(registreD & 0x0C);
    }
    else
        return true;      
}

int main(){
    DDRA = 0xFF; // PORT A est en mode sortie
    DDRB = 0x00;
    DDRC = 0xFF;
    DDRD = 0x00; // PORT D est en mode entrée

    enum State{INIT, ROUGE, VERT, ETEINT};
    State del = INIT;

    for(;;){
        if(PINB & 0x01){
            if(debounce(PIND & 0x0C)){
                switch (del){
                    case INIT:
                        PORTA = 0;
                        if(PIND & 0x04){
                            del = ROUGE;
                        } 
                        break;

                    case ROUGE:
                        PORTA = 1;
                        if(PIND & 0x04){
                            del = VERT;
                        }
                        else if(PIND & 0x08){
                            del = ETEINT;
                        }
                    break;

                    case VERT:
                        PORTA = 2;
                        if(PIND & 0x04 || PIND & 0x08){
                            del = INIT;
                        }
                        break;

                    case ETEINT:
                        PORTA = 0;
                        if(PIND & 0x08){
                            del = VERT;
                        }
                        break;
                }
            }
        }
        else{
            PORTA = 0;
        }
    }
    return 0; 
}