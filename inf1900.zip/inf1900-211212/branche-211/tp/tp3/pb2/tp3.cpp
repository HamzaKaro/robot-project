/*
 * Nom:         TP 3, Problème 2
 * Auteurs:     Hubert Boucher & Alexandre Turcotte
 * Description: Contrôle d'un moteur à l'aide d'un pont H et d'une PWM
 * Version:     1.1
 */



#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);



const double TIME = 2000; // 2s
const int8_t enable = 0x01;
const int8_t direction = 0x02;



enum Intensity { _0, _25, _50, _75, _100 };



// Enables or disables the motor, while keeping the same direction

void Enable()
{ PORTB = enable + direction; }
void Disable()
{ PORTB = direction; }



// These functions are used to generate a cycle for 2 seconds at a certain intensity
//  The code is duplicated since _delay_ms does not accept variables or formulas
//  Therefore, the functions each set the frequency to a particular constant, and the rest of the function is the same

void GenerateCycle_60Hz(Intensity intensity)
{
    const double FREQUENCY = 60;
    const double PERIOD = 1000 / FREQUENCY; // Time (in ms) of one period

    if (intensity == _0)
    {
        Disable();
        _delay_ms(TIME);
        return;
    }
    else if (intensity == _100)
    {
        Enable();
        _delay_ms(TIME);
        return;
    }
    else
    {
        // Loop periods for as many times as that period fits in TIME
        for (double i = 0; i < TIME; i += PERIOD)
        {
            switch (intensity)
            {
                case _25:
                    Enable();
                    _delay_ms(PERIOD * 0.25);
                    Disable();
                    _delay_ms(PERIOD * 0.75);
                    break;

                case _50:
                    Enable();
                    _delay_ms(PERIOD * 0.50);
                    Disable();
                    _delay_ms(PERIOD * 0.50);
                    break;

                case _75:
                    Enable();
                    _delay_ms(PERIOD * 0.75);
                    Disable();
                    _delay_ms(PERIOD * 0.25);
                    break;

                default: return;
            }
        }
    }
}
void GenerateCycle_400Hz(Intensity intensity)
{
    const double FREQUENCY = 400;
    const double PERIOD = 1000 / FREQUENCY; // Time (in ms) of one period

    if (intensity == _0)
    {
        Disable();
        _delay_ms(TIME);
        return;
    }
    else if (intensity == _100)
    {
        Enable();
        _delay_ms(TIME);
        return;
    }
    else
    {
        // Loop periods for as many times as that period fits in TIME
        for (double i = 0; i < TIME; i += PERIOD)
        {
            switch (intensity)
            {
                case _25:
                    Enable();
                    _delay_ms(PERIOD * 0.25);
                    Disable();
                    _delay_ms(PERIOD * 0.75);
                    break;

                case _50:
                    Enable();
                    _delay_ms(PERIOD * 0.50);
                    Disable();
                    _delay_ms(PERIOD * 0.50);
                    break;

                case _75:
                    Enable();
                    _delay_ms(PERIOD * 0.75);
                    Disable();
                    _delay_ms(PERIOD * 0.25);
                    break;

                default: return;
            }
        }
    }
}



int main()
{
    DDRB = 0xff; // PORT B is an output

    PORTB = 0x00; // Direction = 0      (B1 = 0)
                  // Enable will vary   (B0 = 1 or 0)

    for (;;)
    {
        GenerateCycle_60Hz(_0);
        GenerateCycle_60Hz(_25);
        GenerateCycle_60Hz(_50);
        GenerateCycle_60Hz(_75);
        GenerateCycle_60Hz(_100);
        GenerateCycle_400Hz(_0);
        GenerateCycle_400Hz(_25);
        GenerateCycle_400Hz(_50);
        GenerateCycle_400Hz(_75);
        GenerateCycle_400Hz(_100);
    }

    return 0;
}

