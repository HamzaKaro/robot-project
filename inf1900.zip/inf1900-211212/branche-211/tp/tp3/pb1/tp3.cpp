/*
 * Nom:         TP 3, Problème 1
 * Auteurs:     Hubert Boucher & Alexandre Turcotte
 * Description: Allumer une DEL en 3 secondes
 * Version:     1.1
 */

#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);

//Le temps doit être écrit en ms, considérant que la fréquence est environ 100Hz.
//Pour la couleur, c'est 1=vert et 2=rouge.
void turnOff(uint16_t timeToShutdown, uint8_t color){
    uint8_t rapport = 0;

    while(timeToShutdown > 0){
        int a = 100-100*rapport/100;
        int b = 100*rapport/100;

        PORTA = color;
        while(a > 0){
           _delay_us(9);
           a--;
        }

        PORTA = 0;
        while(b > 0){
           _delay_us(9);
           b--;
        }

        if(timeToShutdown%30 == 0){
            rapport++;
        }

        timeToShutdown--;
    }
}

//Pour ce problème, la période doit toujours être de 1kHz (1 ms), seul le rapport 5V vs 0V doit être modifié
int main(){
    DDRA = 0xFF; //PORTA en sortie
    DDRB = 0xFF;
    DDRC = 0xFF;
    DDRD = 0x00; //PORTD en entré
   
    if(PIND & 0x04){
        PORTA = 1;
        turnOff(3000, 1);
       
        PORTA = 2;
        turnOff(3000, 2);
   }
}