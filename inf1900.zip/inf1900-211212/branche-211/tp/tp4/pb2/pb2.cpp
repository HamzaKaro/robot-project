/*
 * Nom:         TP 4, Problème 2
 * Auteurs:     Hubert Boucher & Alexandre Turcotte
 * Description: Machine à état pour un jeu de reflexe avec une DEL
 * Version:     1.1
 */



#include <avr/io.h>
#define F_CPU 8000000
#include <avr/interrupt.h>
#include <util/delay.h>
void _delay_ms(double ms);


volatile bool isNotInterrupt = true;
enum State{Init, Testing, ButtonPressed, TimesUp};
volatile State state;

bool noReboundD2(){
    if(PIND & 0x04){
        _delay_ms(10);
        if(PIND & 0x04) return true;
    }
    return false;
}


ISR ( TIMER1_COMPA_vect ){

    state = TimesUp;
    isNotInterrupt = false;
}


ISR ( INT0_vect ){

    if(noReboundD2()){
        state = ButtonPressed;
        isNotInterrupt = false;
    }
}

void partirMinuterie ( uint16_t duree ) {

    TCNT1 = 0x02;   //mode CTC
    OCR1A = duree;
    TCCR1A = 0x40;  //Toggle OC1A on Compare Match A
    TCCR1B = 0x05;  //divise par 1024
    TCCR1C = 0;
    TIMSK1 = 0x02;  //"Output Compare Match A Interrupt Enable"

    
}

void initialisation ( void ) {
    
    cli ();
   
    DDRD = 0x00; // PORT D is an input
    DDRC = 0xff;
    DDRB = 0x00;
    DDRA = 0xff; // PORT A is an output

    EIMSK |= (1 << INT0);


    EICRA |= (1 << ISC00) | (1 << ISC01) ;

    sei ();
}

void stateEtat(State etat){
    switch (etat){

    case Init:
        PORTA |= 1 << PORTA1;
        break;

    case Testing:
        PORTA &= ~(1 << PORTA1);
        break;

    case ButtonPressed:
        PORTA = 1 << PORTA0;
        break;

    case TimesUp:
        PORTA = 1 << PORTA1;
        break;
    }
}

int main(){
    initialisation();

    _delay_ms(10'000);
    stateEtat(state=Init);
    
    _delay_ms(100);
    stateEtat(state=Testing);

    partirMinuterie(0x1E84); //puisque 8'000'000/1024 = 7812,5 on arrondit à 7812 = 0x1E84

    do { } while ( isNotInterrupt );

    cli ();
    
    stateEtat(state);
}
