
#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);



const double TIME = 2000; // 2s
const int8_t enable = 0x01;
const int8_t direction = 0x02;



enum Intensity { _0, _25, _50, _75, _100 };



void ajustementPWM(Intensity intensity)
{
    switch (intensity)
    {
        case _0:
            OCR1A = 0x0000;
            OCR1B = 0x0000;
            break;

        case _25:
            OCR1A = 0x3FFF;
            OCR1B = 0x3FFF;
            break;

        case _50:
            OCR1A = 0x7FFF;
            OCR1B = 0x7FFF;
            break;

        case _75:
            OCR1A = 0xBFFF;
            OCR1B = 0xBFFF;
            break;

        case _100:
            OCR1A = 0xFFFE;
            OCR1B = 0xFFFE;
            break;
    }
    
    TCCR1A = (1 << COM1A1) | (1 << COM1B1);
    TCCR1B = (1 << CS11);
    TCCR1C = 0;

    _delay_ms(2000);
}



int main()
{
    DDRD = 0xff; // PORT B is an output

    PORTD = 0x00; // Direction = 0      (B1 = 0)
                  // Enable will vary   (B0 = 1 or 0)

    for (;;)
    {
        ajustementPWM(_0);
        ajustementPWM(_25);
        ajustementPWM(_50);
        ajustementPWM(_75);
        ajustementPWM(_100);
    }

    return 0;
}

