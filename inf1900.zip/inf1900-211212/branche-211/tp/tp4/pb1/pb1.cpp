/*
 * Machine à états de Moore contrôlant l'allumage d'une LED, premier problème.
 * Date : 27/01/2021
 * Auteur : Alexandre Turcotte, Hubert Boucher
 * Équipe : 211
 * Groupe 05
*/

/*
 * État présent     Entrée D2   Entrée D3    État suivant     Sortie A
 * INIT                0            0           INIT            0
 * INIT                0            1           INIT            0
 * INIT                1            0           ROUGE           0
 * ROUGE               0            0           ROUGE           1
 * ROUGE               0            1           ETEINT          1
 * ROUGE               1            0           VERT            1
 * VERT                0            0           VERT            2
 * VERT                0            1           INIT            2
 * VERT                1            0           INIT            2
 * ETEINT              0            0           ETEINT          0
 * ETEINT              0            1           VERT            0
 * ETEINT              1            0           ???             0
*/


#include <avr/interrupt.h>
#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);



enum State { INIT, RED, SHUT, GREEN };
volatile State state;



void SetColor()
{
    switch (state)
    {
        case INIT:
            PORTA = 0;
            break;

        case RED:
            PORTA = 1;
            break;

        case SHUT:
            PORTA = 0;
            break;

        case GREEN:
            PORTA = 2;
            break;
    }
}



ISR(INT0_vect, ISR_NAKED)
{
    _delay_ms(30);

    switch (state)
    {
        case INIT:
            state = RED;
            break;

        case RED:
            state = GREEN;
            break;

        case SHUT:
            break;

        case GREEN:
            state = INIT;
            break;
    }

    SetColor();

    EIFR |= (1 << INTF0) ;
    reti();
}



ISR(INT1_vect, ISR_NAKED)
{
    _delay_ms(30);

    switch (state)
    {
        case INIT:
            break;

        case RED:
            state = SHUT;
            break;

        case SHUT:
            state = GREEN;
            break;

        case GREEN:
            state = INIT;
            break;
    }

    SetColor();

    EIFR |= (1 << INTF1) ;
    reti();
}



void initialize()
{
    cli();

    DDRA = 0xFF; // PORT A est en mode sortie
    DDRD = 0x00; // PORT D est en mode entrée

    state = INIT;
    SetColor();

    EICRA |= (1 << ISC01) | (1 << ISC00);
    EICRA |= (1 << ISC11) | (1 << ISC10);
    EIMSK |= (1 << INT0);
    EIMSK |= (1 << INT1);

    sei();
}



int main()
{
    initialize();

    for (;;)
    {
        
    }
    
    return 0; 
}