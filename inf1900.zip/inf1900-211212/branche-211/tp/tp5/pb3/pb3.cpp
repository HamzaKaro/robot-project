/*
 * Nom:         TP 5, Problème 3
 * Auteurs:     Hubert Boucher & Alexandre Turcotte
 * Description: Écrire en mémoire, lire la mémoire et print
 * Version:     1.1
 */



#include <avr/io.h>
#define F_CPU 8000000
#include <avr/interrupt.h>
#include <util/delay.h>
void _delay_ms(double ms);

const int BREAK_CHARACTER = 0xFF;



// De l'USART vers le PC

void transmissionUART ( uint8_t donnee )
{
    /* Wait for empty transmit buffer */
    while ( !( UCSR0A & (1 << UDRE0)));

    /* Put data into buffer, sends the data */
    UDR0 = donnee;
}

void writeEeprom(uint16_t adresse, unsigned char caract){
    while(EECR & (1<<EEPE));

    /* Set up address and Data Registers */
    EEAR = adresse;
    EEDR = caract;

    /* Write logical one to EEMPE */
    EECR |= (1 << EEMPE);
    /* Start eeprom write by setting EEPE */
    EECR |= (1 << EEPE);
}

unsigned char EEPROM_read(unsigned int uiAddress){
    /* Wait for completion of previous write */
    while(EECR & (1<<EEPE))
    ;
    /* Set up address register */
    EEAR = uiAddress;
    /* Start eeprom read by writing EERE */
    EECR |= (1<<EERE);
    /* Return data from Data Register */
    return EEDR;
}

void initialisationUART ( void )
{
    // 2400 bauds. Nous vous donnons la valeur des deux
    //  premier registres pour vous éviter des complications

    UBRR0H = 0;

    UBRR0L = 0xCF;

    // permettre la réception et la transmission par le UART0
    UCSR0A = (1 << RXEN0) | (1 << TXEN0); //Réception et transmission
    UCSR0B = (1 << RXEN0) | (1 << TXEN0); //Réception et transmission

    // Format des trames: 8 bits, 1 stop bits, none parity
    UCSR0C = (0 << USBS0) | (3 << UCSZ00);
}



int main()
{
    int address = 0x0000;
    for ( char c : "Avec le code utilisé pour l'exercice précédent, transmettre les valeurs inscrites en mémoire vers le PC. La console de contrôle série de SimulIDE affichera le contenu de la mémoire eeprom dès que le programme démarre. Cette mémoire sera lue de l'adresse 0x0000 jusqu'à ce qu'une valeur lue soit égale à 0xFF. Vous pouvez jouer un peu avec ce que vous choisissez d’écrire en mémoire." )
    {
        writeEeprom(
            address,
            c
        );
        address++;
    }

    //Éviter de déborder
    writeEeprom(0xFFFF, BREAK_CHARACTER);

    address = 0x00;
    while (true)
    {
        char value = EEPROM_read(address);
        if ((int)value == BREAK_CHARACTER)
            break;
        transmissionUART(value);
        address++;
    }
}


