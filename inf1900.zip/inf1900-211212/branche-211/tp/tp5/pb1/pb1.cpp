/*
 * Écriture de "Polytechnique Montreal" dans EEPROM.
 * Date : 17/02/2021
 * Auteur : Alexandre Turcotte, Hubert Boucher
 * Équipe : 211
 * Groupe 05
*/


#include <avr/interrupt.h>
#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
void _delay_ms(double ms);

using namespace std;



enum State { INIT, RED, SHUT, GREEN };
volatile State state;


void SetColor()
{
    switch (state)
    {
        case INIT:
            PORTA = 0;
            break;

        case RED:
            PORTA = 1;
            break;

        case SHUT:
            PORTA = 0;
            break;

        case GREEN:
            PORTA = 2;
            break;
    }
}


void initialize()
{
    cli();

    DDRA = 0xFF; // PORT A est en mode sortie
    DDRD = 0x00; // PORT D est en mode entrée

    sei();
}

void writeEeprom(uint16_t adresse, unsigned char caract){
    while(EECR & (1<<EEPE));

    /* Set up address and Data Registers */
    EEAR = adresse;
    EEDR = caract;

    /* Write logical one to EEMPE */
    EECR |= (1<<EEMPE);
    /* Start eeprom write by setting EEPE */
    EECR |= (1<<EEPE);
}

unsigned char readEeprom(unsigned int address){
    while(EECR & (1<<EEPE));

    /* Set up address register */
    EEAR = address;

    /* Start eeprom read by writing EERE */
    EECR |= (1<<EERE);
    /* Return data from Data Register */
    return EEDR;
}


int main()
{
    initialize();
    uint16_t adr = 0;
    char polymtl[46]=  "*P*O*L*Y*T*E*C*H*N*I*Q*U*E* *M*O*N*T*R*E*A*L*";

    for(uint8_t i=0; i<46; i++){ //45 est le nombre de caractère à écrire
        writeEeprom(adr, polymtl[i]);
        adr += 0x8;
    }

    char memoire[46];
    adr = 0;

    for(uint8_t i = 0; i < 46; i++){
        memoire[i] = readEeprom(adr);
        adr += 0x08;
    }

    bool isSame = true;
    for(uint8_t i = 0; i < 46; i++) if(memoire[i] != polymtl[i]) isSame = false;

    if(isSame) PORTA = 0x01;
    else PORTA = 0x02;
    
    return 0; 
}