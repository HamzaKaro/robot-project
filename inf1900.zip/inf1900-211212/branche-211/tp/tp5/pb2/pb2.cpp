/*
 * Nom:         TP 5, Problème 2
 * Auteurs:     Hubert Boucher & Alexandre Turcotte
 * Description: Print une série de caractères dans la console de SimulIDE
 * Version:     1.1
 */

#include <avr/io.h>
#define F_CPU 8000000
#include <avr/interrupt.h>
#include <util/delay.h>
void _delay_ms(double ms);



// De l'USART vers le PC

void transmissionUART ( uint8_t donnee )
{
    /* Wait for empty transmit buffer */
    while ( !( UCSR0A & (1 << UDRE0)));

    /* Copy 9th bit to TXB8 */
    //UCSR0B &= ~(1 << TXB80);
    //if ( donnee & 0x0100 )
    //UCSR0B |= (1 << TXB80);
    /* Put data into buffer, sends the data */
    UDR0 = donnee;
}

void initialisationUART ( void )
{
    // 2400 bauds. Nous vous donnons la valeur des deux
    //  premier registres pour vous éviter des complications

    UBRR0H = 0;

    UBRR0L = 0xCF;

    // permettre la réception et la transmission par le UART0
    UCSR0A = (1 << RXEN0) | (1 << TXEN0); //Réception et transmission
    UCSR0B = (1 << RXEN0) | (1 << TXEN0); //Réception et transmission

    // Format des trames: 8 bits, 1 stop bits, none parity
    UCSR0C = (0 << USBS0) | (3 << UCSZ00);
}



int main()
{
    char mots[34] = "Le simulateur SimulIDE en INF1900";
    mots[33] = '\n';

    uint8_t i, j;

    for ( i = 0; i < 100; i++ )
    {
        for ( j = 0; j < 34; j++ )
        {
            transmissionUART ( mots[j] );
        }
    }
}


