/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une led bicolore en fonction
 * de 2 boutons-poussoirs reliés a D2 et D3. Le fonctionnement  diffère 
 * selon le problème.
 * Problème1 :Si on appuie sur D2, la led devient verte et à partir de cet
 * état, il faut appuyer 3 fois sur D3 pour la rendre rouge. Puis, une seconde
 * plus tard, elle s'eteint automatiquement. Voir la table des etats ci dessous.
 
 *Table des etats probleme 1:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Vert1        !     0     !      0    !
 Vert1        ! 0  ! X  ! Vert2        !     0     !      0    !        
 Vert2        ! X  ! 1  ! Rouge11      !     1     !      0    !
 Rouge11      ! X  ! 0  ! Rouge12      !     1     !      0    !
 Rouge12      ! X  ! 1  ! Rouge21      !     1     !      0    !
 Rouge21      ! X  ! 0  ! Rouge22      !     1     !      0    !
 Rouge22      ! X  ! 1  ! Rouge31      !     1     !      0    !
 Rouge31      ! X  ! 0  ! Rouge32      !     1     !      0    !
 Rouge32      ! X  ! X  ! init         !     0     !      1    !

 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <util/delay.h>


bool debounceD(uint8_t  port){
    if(PIND & (1<<port)){
        _delay_ms(10);
        return(PIND & (1<<port));
    }        
    return false;
}
/*
***Fonction problème1                                                          ***
***return void                                                                 ***
***la fonction permet de traiter le problème 1 en utilisant un automate        ***
*** Un appuie et une relache du bouton sont representés par différents états   ***
*** Afin de remplir la fonction qui permet de compter le nombre des appuies,   ***
*** on a fait le compte grâce a l'automate en attribuant des états différents  ***
*** pour chaque relache du bouton.                                             ***
*/
void probleme1(){
    enum Sortie{A0=0b01,A1=0b10,null=0};
    enum Etat{init,vert1,vert2,rouge11,rouge12,rouge21,rouge22,rouge31,rouge32};
 //    enum Etat{init,vert,rouge};

    Etat etatActuel=init;
    Sortie sortieActuel=null;
    while(true){
    switch(etatActuel){
        case init:
            if(debounceD(2)){
                etatActuel=vert1;
                sortieActuel=null;
            }
            sortieActuel=null;
            break;
        case vert1:
            if(!debounceD(2)){
                etatActuel=vert2;
                sortieActuel=A0;
            }
            break;
        case vert2:
            if(debounceD(3)){
                etatActuel=rouge11;
                sortieActuel=A0;
            }
            break;
        case rouge11:
            if(!debounceD(3)){
                etatActuel=rouge12;
                sortieActuel=A0;
                PORTA=0x08;
            }
            break;
        case rouge12:
            if(debounceD(3)){
                etatActuel=rouge21;
                sortieActuel=A0;
            }
            break;
        case rouge21:
            if(!debounceD(3)){
                etatActuel=rouge22;
                sortieActuel=A0;
                PORTA=0x10;
            }
            break;
        case rouge22:
            if(debounceD(3)){
                etatActuel=rouge31;
                sortieActuel=A0;
            }
            break;
        case rouge31:
            if(!debounceD(3)){
                etatActuel=rouge32;
                sortieActuel=A1;
            }
            break;
        case rouge32:
            _delay_ms(1000);
            etatActuel=init;
            sortieActuel=null;
            break;
    }
    PORTA = sortieActuel;
    }    
}

int main()
{
  DDRA = 0xff; //PORT A est en mode sortie
  DDRD = 0x00; //PORT D est en mode entree

  probleme1();   
  
  return 0; 
}
