/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une led bicolore en fonction
 * de 2 boutons-poussoirs reliés a D2 et D3. Le fonctionnement  diffère 
 * selon le problème.
 
 * Problème2 : La led reste éteinte tant qu'on n'appuie pas sur D2.Une fois D2 
 * appuyé, la led est rouge et si on appuie dessus une deuxième fois, la led devient verte.
 * Par contre, si de l'état (rouge) on appuie sur D3, la led s'eteint. De cet état, si on 
 * appuie une deuxième fois sur D3 la led devient verte. Lorsque la led est verte, il suffit  
 * d'appuyer sur n'importe quel bouton pour eteindre cette dernière. Voir la table ci dessous.

  *Table des etats probleme 2:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Rouge1       !     0     !      0    !
 init         ! 0  ! 1  ! init         !     0     !      0    !
 Rouge1       ! 0  ! X  ! Rouge2       !     0     !      0    !        
 Rouge2       ! 1  ! X  ! Vert11       !     0     !      1    !
 Rouge2       ! 0  ! 1  ! off1         !     0     !      1    !
 off1         ! X  ! 0  ! off2         !     0     !      1    !
 off2         ! X  ! 1  ! Vert21       !     0     !      0    !
 Vert21       ! X  ! 0  ! Vert2        !     0     !      0    !
 Vert11       ! 0  ! X  ! Vert2        !     0     !      1    !
 Vert2        ! X  ! 1  ! retour       !     1     !      0    !
 Vert2        ! 1  ! X  ! retour       !     1     !      0    !
 retour       ! 0  ! 0  ! init         !     1     !      0    !
 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <util/delay.h>



bool debounceD(uint8_t  port){
    if(PIND & (1<<port)){
        _delay_ms(10);
        return(PIND & (1<<port));
    }        
    return false;
}

/*
***Fonction problème2                                                          ***
***return void                                                                 ***
***la fonction permet de traiter le problème 2 en utilisant un automate        ***
*** Un appuie et une relache du bouton sont representés par différents états   ***
*** Afin de remplir la fonction qui permet de compter le nombre des appuies,   ***
*** on a fait le compte grâce a l'automate en attribuant des états différents  ***
*** pour chaque relache du bouton.                                             ***
*/
void probleme2(){
    enum Sortie{A0=0b01,A1=0b10,null=0};
    enum Etat{init,vert11,vert21,vert2,rouge1,rouge2,off1,off2,retour};
   //    enum Etat{init,vert,rouge};

    Etat etatActuel=init;
    Sortie sortieActuel=null;
    while(true){
    switch(etatActuel){
        case init:
            if(debounceD(2)){     // priorite au rouge1 au cas ou on appuie sur d2 et d3 ensemble.
                etatActuel=rouge1;
               
            }
            else if(debounceD(3)){
                etatActuel=init;
                
            }
            sortieActuel=null;
            break;
        case rouge1:
            if(!debounceD(2)){
                etatActuel=rouge2;
                sortieActuel=A1;
            }
        
            break;
        case rouge2:
            if(debounceD(2)){    // priorite au vert11 au cas ou on appuie sur d2 et d3 ensemble. 
                etatActuel=vert11;
                
            }else if(debounceD(3)){
                etatActuel=off1; 
            }
            sortieActuel=A1;
            break;
        case vert11:
            if(!debounceD(2)){
                etatActuel=vert2;
                sortieActuel=A0;
            }
            break;
        case vert2:
            if(debounceD(3)||debounceD(2)){
                etatActuel=retour;
                sortieActuel=A0;
            }
            break;
        case retour:
            if(!(debounceD(3)||debounceD(2))){
                etatActuel=init;
                sortieActuel=null;
            }
            break;
        case off1:
            if(!debounceD(3)){
                etatActuel=off2;
                sortieActuel=null;
            }
            break;
        case off2:
            if(debounceD(3)){
                etatActuel=vert21;
                sortieActuel=null;
            }
            break;
        case vert21:
            if(!debounceD(3)){
                etatActuel=vert2;
                sortieActuel=A0;
            }
            break;
    }
    PORTA = sortieActuel;
    }
}
int main()
{
  DDRA = 0xff; //PORT A est en mode sortie
  DDRD = 0x00; //PORT D est en mode entree

  probleme2();
  
  return 0; 
}
