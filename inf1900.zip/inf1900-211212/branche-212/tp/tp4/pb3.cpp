/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une led bicolore en fonction
 * de 2 boutons-poussoirs reliés a D2 et D3. Le fonctionnement  diffère 
 * selon le problème.
 * Problème1 :Si on appuie sur D2, la led devient verte et à partir de cet
 * état, il faut appuyer 3 fois sur D3 pour la rendre rouge. Puis, une seconde
 * plus tard, elle s'eteint automatiquement. Voir la table des etats ci dessous.
 
 *Table des etats probleme 1:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Vert1        !     0     !      0    !
 Vert1        ! 0  ! X  ! Vert2        !     0     !      0    !        
 Vert2        ! X  ! 1  ! Rouge11      !     1     !      0    !
 Rouge11      ! X  ! 0  ! Rouge12      !     1     !      0    !
 Rouge12      ! X  ! 1  ! Rouge21      !     1     !      0    !
 Rouge21      ! X  ! 0  ! Rouge22      !     1     !      0    !
 Rouge22      ! X  ! 1  ! Rouge31      !     1     !      0    !
 Rouge31      ! X  ! 0  ! Rouge32      !     1     !      0    !
 Rouge32      ! X  ! X  ! init         !     0     !      1    !

 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <util/delay.h>
#include <avr/interrupt.h>



void ajustementPWM ( uint8_t pourcent) {

// mise à un des sorties OC1A et OC1B sur comparaison

// réussie en mode PWM 8 bits, phase correcte

// et valeur de TOP fixe à 0xFF (mode #1 de la table 16-5

// page 130 de la description technique du ATmega324PA)

OCR1A = 0;

OCR1B =254 ;//2^8-1=255 255.0/100


// division d'horloge par 8 - implique une frequence de PWM fixe

TCCR1A = (1<<WGM10) |  (1<<COM1B1)  ;

TCCR1B =  (1<<CS11);

TCCR1C = 0;

}

int main()
{
  DDRB=0xff;
  DDRD=0xff;
  PORTB=0b10;//direction

  while(true){
       

        ajustementPWM(99);
        // _delay_ms(2000);
        // ajustementPWM(25);
        // _delay_ms(2000);
        // ajustementPWM(50);
        // _delay_ms(2000);
        // ajustementPWM(75);
        // _delay_ms(2000);
        // ajustementPWM(100);
        // _delay_ms(2000);
  }
  return 0; 
}
