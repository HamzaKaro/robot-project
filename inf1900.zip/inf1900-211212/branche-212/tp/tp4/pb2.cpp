/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une led bicolore en fonction
 * de 2 boutons-poussoirs reliés a D2 et D3. Le fonctionnement  diffère 
 * selon le problème.
 * Problème1 :Si on appuie sur D2, la led devient verte et à partir de cet
 * état, il faut appuyer 3 fois sur D3 pour la rendre rouge. Puis, une seconde
 * plus tard, elle s'eteint automatiquement. Voir la table des etats ci dessous.
 
 *Table des etats probleme 1:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Vert1        !     0     !      0    !
 Vert1        ! 0  ! X  ! Vert2        !     0     !      0    !        
 Vert2        ! X  ! 1  ! Rouge11      !     1     !      0    !
 Rouge11      ! X  ! 0  ! Rouge12      !     1     !      0    !
 Rouge12      ! X  ! 1  ! Rouge21      !     1     !      0    !
 Rouge21      ! X  ! 0  ! Rouge22      !     1     !      0    !
 Rouge22      ! X  ! 1  ! Rouge31      !     1     !      0    !
 Rouge31      ! X  ! 0  ! Rouge32      !     1     !      0    !
 Rouge32      ! X  ! X  ! init         !     0     !      1    !

 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <util/delay.h>
#include <avr/interrupt.h>

volatile uint8_t minuterieExpiree;

volatile uint8_t boutonPoussoir;


void initialisation ( void ) {

boutonPoussoir=0;
// cli est une routine qui bloque toutes les interruptions.

// Il serait bien mauvais d'être interrompu alors que

// le microcontroleur n'est pas prêt...

cli ();


// configurer et choisir les ports pour les entrées

// et les sorties. DDRx... Initialisez bien vos variables

  DDRA = 0xff; //PORT A est en mode sortie
  DDRD = 0x00; //PORT D est en mode entree


// cette procédure ajuste le registre EIMSK

// de l’ATmega324PA pour permettre les interruptions externes

EIMSK |= (1 << INT0) ;

// il faut sensibiliser les interruptions externes aux

// changements de niveau du bouton-poussoir

// en ajustant le registre EICRA

EICRA |= (1 << ISC11) ;     


// sei permet de recevoir à nouveau des interruptions.

sei ();

}



ISR ( TIMER1_COMPA_vect) {

minuterieExpiree = 1;

}

void partirMinuterie ( uint16_t duree ) {

minuterieExpiree = 0;

// mode CTC du timer 1 avec horloge divisée par 1024

// interruption après la durée spécifiée

TCNT1 = 0x00;

OCR1A = duree;

TCCR1A =  (1<<COM1A0) | (1<<WGM12); 

TCCR1B =  (1<<CS12) | (1<<CS10);

TCCR1C = 0;

TIMSK1 = 1<<OCIE1A;
//EIMSK |= (1 << INT0)|(1 << INT1) ;

}

ISR ( INT0_vect ) {

// anti-rebond

_delay_ms ( 10 );

    // se souvenir ici si le bouton est pressé ou relâché{     
        boutonPoussoir=1;
    

}


int main()
{

  initialisation();
  _delay_ms(2000);
  PORTA=0b10;
  _delay_ms(100);
  PORTA=0b00;
  partirMinuterie(7812);//x*1024/8/10^6=1

  do {

    // attendre qu'une des deux variables soit modifiée

    // par une ou l'autre des interruptions.
    PORTA=0b01;

  } while ( minuterieExpiree == 0 && boutonPoussoir == 0 );

    

    // Une interruption s'est produite. Arrêter toute

    // forme d'interruption. Une seule réponse suffit.

    cli ();

    // Verifier la réponse
    PORTA=0b00;
    
    _delay_ms(500);
    PORTA=0b10;
    
    _delay_ms(500);
    PORTA=0b00;
    
    _delay_ms(500);
    PORTA=0b10;
    
    _delay_ms(500);
    PORTA=0b00;
    
    _delay_ms(500);
    PORTA=0b10;
    
    _delay_ms(500);
    PORTA=0b00;
    
    _delay_ms(500);
   
  return 0; 
}
