/*****************************************************************************************
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 6
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une DEL bicolore en fonction
 * de l'intensite de la lumiere: on divise l'intensite lu en 3 intervalles,
 * si la lumiere est basse la DEL prend la couleur verte (courant dans B0)
 * si la lumiere est forte la DEL devient rouge
 * sinon dans le cas ou l'intensite de la lumiere est moyenne la DEL devient ambre.

 * entrees/sorties:
 * A0 entree
 * B0/B1 sorties  
 
 *Mesures faits avant de commencer:
 *Vref est ajustee a 5v
 *on a verifie la valeur maximale (lumniere forte) de la tension avec un voltmetre = 3.62V
 *on a verifie la valeur minimale (lumniere basse) de la tension avec un voltmetre = 2.38V

 *****************************************************************************************/

#define 	F_CPU   8000000UL
#include <avr/io.h>  
#include <util/delay.h>
#include "can.h" 

const uint8_t A0 = 0;
const uint8_t VALEUR_CAPTEUR_MIN = 121;//quand la lumiere est forte le voltage =2.38 V => VALEUR_CAPTEUR_MIN=2.38/5*255=121
const uint8_t VALEUR_CAPTEUR_MAX = 185;//quand la lumiere est faible le voltage =3.57 V => VALEUR_CAPTEUR_MAX=3.62/5*255=185
const uint8_t TAILLE_INTERVALLE = (VALEUR_CAPTEUR_MAX-VALEUR_CAPTEUR_MIN)/3;//On a besoin de 3 intervalles +- de meme taille
enum Sortie{B0=0b01,B1=0b10};

/**********************************************************************************
 * cette fonction permet d'initialiser les ports A et B (A0 entree ; B0,B1 sorties)
 * retourne void
 *  parametre void
 **********************************************************************************/

void initialisation(){
    DDRA=0x00;
    DDRB=B0 | B1;
}

/**********************************************************************************
 * cette fonction permet de generer la couleur ambre
 * retourne void
 *  parametre void
 **********************************************************************************/
void ambre(){
    PORTB = B1;     
    _delay_ms(0.5);
    PORTB =B0; 
    _delay_ms(0.4);
}

int main(void)
{
    uint8_t entreeAnalogique;
    can convertisseur ;   
    initialisation();
    while(true){
        entreeAnalogique= (convertisseur.lecture(A0) >> 2);                                                         //garder que les 8 bits les plus significatifs
        if(entreeAnalogique>VALEUR_CAPTEUR_MIN && entreeAnalogique<(VALEUR_CAPTEUR_MIN+TAILLE_INTERVALLE)){         //on divise entreeAnalogique en 3 intervalles
            PORTB = B0;                                                                                             //vert
        }else if (entreeAnalogique<VALEUR_CAPTEUR_MAX && entreeAnalogique>(VALEUR_CAPTEUR_MAX-TAILLE_INTERVALLE)){
            PORTB = B1;                                                                                             //rouge
        }
        else {                //intervalle du milieu ou erreur (mais vu que entreeAnalogique est toujours entre VALEUR_CAPTEUR_MIN et VALEUR_CAPTEUR_MAX le else 
            ambre();        //permet de toujours traiter l'intrvalle du milieu) 
        }
    }
}