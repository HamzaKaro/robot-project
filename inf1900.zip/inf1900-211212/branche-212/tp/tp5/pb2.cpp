/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une led bicolore en fonction
 * de 2 boutons-poussoirs reliés a D2 et D3. Le fonctionnement  diffère 
 * selon le problème.
 * Problème1 :Si on appuie sur D2, la led devient verte et à partir de cet
 * état, il faut appuyer 3 fois sur D3 pour la rendre rouge. Puis, une seconde
 * plus tard, elle s'eteint automatiquement. Voir la table des etats ci dessous.
 
 *Table des etats probleme 1:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Vert1        !     0     !      0    !
 Vert1        ! 0  ! X  ! Vert2        !     0     !      0    !        
 Vert2        ! X  ! 1  ! Rouge11      !     1     !      0    !
 Rouge11      ! X  ! 0  ! Rouge12      !     1     !      0    !
 Rouge12      ! X  ! 1  ! Rouge21      !     1     !      0    !
 Rouge21      ! X  ! 0  ! Rouge22      !     1     !      0    !
 Rouge22      ! X  ! 1  ! Rouge31      !     1     !      0    !
 Rouge31      ! X  ! 0  ! Rouge32      !     1     !      0    !
 Rouge32      ! X  ! X  ! init         !     0     !      1    !

 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <util/delay.h>
#include <string.h>

volatile uint8_t minuterieExpiree;

volatile uint8_t boutonPoussoir;

void initialisationUART ( void ) {

// 2400 bauds. Nous vous donnons la valeur des deux

// premier registres pour vous éviter des complications

UBRR0H = 0;

UBRR0L = 0xCF;

// permettre la réception et la transmission par le UART0

UCSR0A = 1<<UDRE0 ;

UCSR0B = (1<<RXEN0)|(1<<TXEN0); ;

// Format des trames: 8 bits, 1 stop bits, none parity

UCSR0C = (1<<UCSZ00)|(1<<UCSZ01) ;

}
// De l'USART vers le PC

void transmissionUART ( uint8_t donnee ) {

while ( !( UCSR0A & (1<<UDRE0)) )
  _delay_ms(30) ;
UDR0 = donnee;

}
int main()
{
  initialisationUART();
  char mots[34] = "Le simulateur SimulIDE en INF1900";

  uint8_t i, j;

  for ( i = 0; i < 100; i++ ) {

    for ( j=0; j < 33; j++ ) {

      transmissionUART ( mots[j] );

    }

  }
   
  return 0; 
}
