/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 
 * Description: Ce programme permet d'allumer une led bicolore en fonction
 * de 2 boutons-poussoirs reliés a D2 et D3. Le fonctionnement  diffère 
 * selon le problème.
 * Problème1 :Si on appuie sur D2, la led devient verte et à partir de cet
 * état, il faut appuyer 3 fois sur D3 pour la rendre rouge. Puis, une seconde
 * plus tard, elle s'eteint automatiquement. Voir la table des etats ci dessous.
 
 *Table des etats probleme 1:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Vert1        !     0     !      0    !
 Vert1        ! 0  ! X  ! Vert2        !     0     !      0    !        
 Vert2        ! X  ! 1  ! Rouge11      !     1     !      0    !
 Rouge11      ! X  ! 0  ! Rouge12      !     1     !      0    !
 Rouge12      ! X  ! 1  ! Rouge21      !     1     !      0    !
 Rouge21      ! X  ! 0  ! Rouge22      !     1     !      0    !
 Rouge22      ! X  ! 1  ! Rouge31      !     1     !      0    !
 Rouge31      ! X  ! 0  ! Rouge32      !     1     !      0    !
 Rouge32      ! X  ! X  ! init         !     0     !      1    !

 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <string.h> 
#include <util/delay.h>
#include <avr/eeprom.h>

#define BLKSIZE 23
#define DATA 0x10
uint16_t EEMEM adresse =0x0000;
char message[] = "POLYTECHNIQUE MONTREAL";
int main(void)
{
DDRA=0xff;
//write byte to location eechar
eeprom_write_block ((const void *)message ,( void *) adresse, BLKSIZE);
char blockLu [BLKSIZE];
_delay_ms(30);
adresse=0;
eeprom_read_block ((void *)blockLu, (const void *) adresse , BLKSIZE);
_delay_ms(30);

    //  for(i=0;i<BLKSIZE;i++) {
    //    if (tab1[i]!=tab2[i]) return 0;
    //  }
    //  return 1;
if(strcmp(blockLu,message)==0){
    PORTA=0b01;
}else{
    PORTA=0b10;
}
}
