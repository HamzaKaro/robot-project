/*
 * Nom : Hamza Karoui (2012635),David Amoussa (2085243).
 * Travail : TRAVAIL_PRATIQUE 2
 * Section # : 5
 * Équipe # : 212
 * Correcteur : Eya-Tom Augustin Sangam, Tristan Rioux 
 * Description: ce programme permet d'allumer un Led bicolore en fonction
 *de 2 boutons-poussoirs relies a D2 et D3. le fonctionnement  differe 
 * selon le probleme:
 * Probleme1:si on appuie sur D2 la led devient verte et a partir de cet
 * etat il faut appuyer 3 fois sur D3 pour la rendre rouge pendant 1 seconde
 * puis elle s'eteint. voir la table des etats ci dessous.
 * Probleme2: la led reste eteinte tant qu'on n'appuie pas sur D2.Une fois D2 
 * appuye, si on le fait une deuxieme fois la led devient verte par contre si
 * de cette etat on appuie sur D3 la led s'eteint et si on appuie une 2 eme fois
 * sur D3 la led devient verte. Lorsque la led est verte il suffit d'appuyer sur 
 * n'importe quel bouton pour eteindre celle-ci. voir la table ci dessous.
 *Table des etats probleme 1:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Vert1        !     0     !      0    !
 Vert1        ! 0  ! X  ! Vert2        !     0     !      0    !        
 Vert2        ! X  ! 1  ! Rouge11      !     1     !      0    !
 Rouge11      ! X  ! 0  ! Rouge12      !     1     !      0    !
 Rouge12      ! X  ! 1  ! Rouge21      !     1     !      0    !
 Rouge21      ! X  ! 0  ! Rouge22      !     1     !      0    !
 Rouge22      ! X  ! 1  ! Rouge31      !     1     !      0    !
 Rouge31      ! X  ! 0  ! Rouge32      !     1     !      0    !
 Rouge32      ! X  ! X  ! init         !     0     !      1    !

  *Table des etats probleme 2:
 Etat present ! D2 ! D3 ! Etat suivant ! Sortie A0 ! Sortie A1 !
 init         ! 1  ! X  ! Rouge1       !     0     !      0    !
 init         ! 0  ! 1  ! init         !     0     !      0    !
 Rouge1       ! 0  ! X  ! Rouge2       !     0     !      0    !        
 Rouge2       ! 1  ! X  ! Vert11       !     0     !      1    !
 Rouge2       ! 0  ! 1  ! off1         !     0     !      1    !
 off1         ! X  ! 0  ! off2         !     0     !      1    !
 off2         ! X  ! 1  ! Vert21       !     0     !      0    !
 Vert21       ! X  ! 0  ! Vert2        !     0     !      0    !
 Vert11       ! 0  ! X  ! Vert2        !     0     !      1    !
 Vert2        ! X  ! 1  ! retour       !     1     !      0    !
 Vert2        ! 1  ! X  ! retour       !     1     !      0    !
 retour       ! 0  ! 0  ! init         !     1     !      0    !

 *
 */

#define 	F_CPU   8000000UL
#include <avr/io.h> 
#include <util/delay.h>



bool debounceD(uint8_t  port){
    if(PIND & (1<<port)){
        _delay_ms(10);
        return(PIND & (1<<port));
    }        
    return false;
}
/*
***Fonction probleme1                                                          ***
***return void                                                                 ***
***la fonction permet de traiter le probleme 1 en utilisant un automate        ***
*** Un appuie et une relache du bouton sont represente par des etats differents***
*** Afin de remplir la fonction qui permet de compter le nombre des appuies,   ***
*** on a fait le compte grace a l'automate en attribuant des etats differents  ***
*** chaque relache du bouton                                                   ***
*/
void probleme1(){
    enum Sortie{A0=0b01,A1=0b10,null=0};

    Sortie sortieActuel=null;
    while(true){
       
        sortieActuel=A0;
        unsigned b=1000;//en us: //1kHz=1000s^-1=>b=1/1000s=1ms=1000us  
        unsigned a=b;   //donc a=b au debut et diminuera jusqu,elle devienne 0.
        const float TEMPS_UNITAIRE=0.1;
        const unsigned NOMBRE_DE_PERIODES_IDENTIQUES=3;//permet de regler la frequence.
        while(a!=0){   
            for(unsigned n=0;n<NOMBRE_DE_PERIODES_IDENTIQUES;n++){                 //sachant que la led s'eteint en 3s, le nombre de periode N=3*1000ms/b=3000/1ms= 3000 periodes  //cette boucle sert a generer des periode identique afin d'avoir 1kHz et eteindre la led en 3s
                PORTA = sortieActuel;
                for(unsigned i=0;i<a;i++)//delay prend des constantes donc on fera plusieur delays selon le besoin 
                    _delay_us(TEMPS_UNITAIRE);
                PORTA = null;                      //la somme des 2 delay doit
                for(unsigned i=0;i<b-a;i++)
                    _delay_us(TEMPS_UNITAIRE);
            }
           a=a-1;
        }
        _delay_ms(200);
        a=b;                            //donc a=b au debut et diminuera jusqu,elle devienne 0.
        sortieActuel=A1;
        while(a!=0){   
            for(unsigned n=0;n<3;n++){                 //sachant que la led s'eteint en 3s, le nombre de periode N=3*1000ms/b=3000/1ms= 3000 periodes  //cette boucle sert a generer des periode identique afin d'avoir 1kHz et eteindre la led en 3s
                PORTA = sortieActuel;
                for(unsigned i=0;i<a;i++)//delay prend des constantes donc on fera plusieur delays selon le besoin 
                    _delay_us(0.1);
                PORTA = 0;                      //la somme des 2 delay doit
                for(unsigned i=0;i<b-a;i++)
                    _delay_us(0.1);
            }
           a=a-1;
        }
        _delay_ms(200);
    }
}
int main()
{
  DDRA = 0xff; //PORT A est en mode sortie
  DDRD = 0x00; //PORT D est en mode entree
 
  probleme1(); //enlever les commentaires pour tester 
  
  return 0; 
}



